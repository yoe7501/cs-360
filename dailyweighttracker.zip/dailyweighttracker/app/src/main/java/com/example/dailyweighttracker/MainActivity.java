package com.example.dailyweighttracker;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput, weightInput;
    private Button loginButton, registerButton, submitWeightButton;
    private GridView weightGridView;
    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        db = dbHelper.getWritableDatabase();

        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        weightInput = findViewById(R.id.weight_input);
        loginButton = findViewById(R.id.login_button);
        registerButton = findViewById(R.id.register_button);
        submitWeightButton = findViewById(R.id.submit_weight_button);
        weightGridView = findViewById(R.id.weight_grid_view);

        loginButton.setOnClickListener(v -> loginUser());
        registerButton.setOnClickListener(v -> registerUser());
        submitWeightButton.setOnClickListener(v -> addWeightEntry());
    }

    private void loginUser() {
        String username = usernameInput.getText().toString();
        String password = passwordInput.getText().toString();

        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?", new String[]{username, password});

        if (cursor.moveToFirst()) {
            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
            displayUserWeights(username);
        } else {
            Toast.makeText(this, "Invalid credentials!", Toast.LENGTH_SHORT).show();
        }

        cursor.close();
    }

    private void registerUser() {
        String username = usernameInput.getText().toString();
        String password = passwordInput.getText().toString();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long result = db.insert("users", null, values);

        if (result != -1) {
            Toast.makeText(this, "User registered successfully!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error registering user.", Toast.LENGTH_SHORT).show();
        }
    }

    private void addWeightEntry() {
        String weight = weightInput.getText().toString();

        if (weight.isEmpty()) {
            Toast.makeText(this, "Please enter a weight!", Toast.LENGTH_SHORT).show();
            return;
        }

        String username = usernameInput.getText().toString();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("weight", weight);

        long result = db.insert("weights", null, values);

        if (result != -1) {
            Toast.makeText(this, "Weight added successfully!", Toast.LENGTH_SHORT).show();
            displayUserWeights(username);
        } else {
            Toast.makeText(this, "Error adding weight.", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayUserWeights(String username) {
        Cursor cursor = db.rawQuery("SELECT * FROM weights WHERE username = ?", new String[]{username});

        // Update your GridView with the data here (use a CursorAdapter or custom adapter)
    }

    private void sendSMSNotification(String message) {
        SmsManager smsManager = SmsManager.getDefault();
        // send SMS to a predefined number or from user input
        smsManager.sendTextMessage("phoneNumber", null, message, null, null);
    }
}
